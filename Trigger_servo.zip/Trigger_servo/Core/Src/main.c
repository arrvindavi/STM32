/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2025 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

#include <stdio.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define RS485_RE_DE_Pin        GPIO_PIN_4
#define RS485_RE_DE_GPIO_Port  GPIOA
#define SERVO_ID               1
#define SERVO_MAX_ANGLE        240.0f
#define SERVO_MAX_POS          1023
#define SERVO_MOVE_TIME        0x20


/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
UART_HandleTypeDef huart2;
UART_HandleTypeDef huart3;

/* USER CODE BEGIN PV */
/* ---- Debug UART (USART3) ---- */

uint8_t uart2_rx_byte;
volatile uint8_t packet_ready = 0;
uint8_t packet_buf[32];
uint8_t packet_len = 0;

//* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_USART3_UART_Init(void);

/* USER CODE BEGIN PFP */
static inline void RS485_TxEnable(void)  { HAL_GPIO_WritePin(RS485_RE_DE_GPIO_Port, RS485_RE_DE_Pin, GPIO_PIN_SET); }
static inline void RS485_TxDisable(void) { HAL_GPIO_WritePin(RS485_RE_DE_GPIO_Port, RS485_RE_DE_Pin, GPIO_PIN_RESET); }

/* ------------------- Checksum ------------------- */
static uint8_t calc_checksum(uint8_t *data, uint8_t len) {
    uint16_t sum = 0;
    for (uint8_t i = 0; i < len; i++) sum += data[i];
    return (uint8_t)(~sum);
}

/* ------------------- Send packet ------------------- */
static void send_packet(uint8_t id, uint8_t instruction, const uint8_t *params, uint8_t param_len) {
    uint8_t packet[32];
    uint8_t idx = 0;

    packet[idx++] = 0xFF;
    packet[idx++] = 0xFF;
    packet[idx++] = id;
    packet[idx++] = param_len + 2; // LEN
    packet[idx++] = instruction;

    memcpy(&packet[idx], params, param_len);
    idx += param_len;
    packet[idx++] = calc_checksum(&packet[2], param_len + 3);

    RS485_TxEnable();
    HAL_Delay(1);
    HAL_UART_Transmit(&huart2, packet, idx, HAL_MAX_DELAY);
    RS485_TxDisable();
}

/* ------------------- Servo control ------------------- */
void servo_set_angle(float angle_deg) {
    if (angle_deg < 0) angle_deg = 0;
    if (angle_deg > SERVO_MAX_ANGLE) angle_deg = SERVO_MAX_ANGLE;

    uint16_t pos = (uint16_t)((angle_deg / SERVO_MAX_ANGLE) * SERVO_MAX_POS);
    uint8_t params[] = { 0x2A, pos & 0xFF, pos >> 8, SERVO_MOVE_TIME, 0x00 };
    send_packet(SERVO_ID, 0x03, params, sizeof(params));
}

/* ------------------- Feedback request ------------------- */
void feedback(void) {
    struct { uint8_t addr; uint8_t size; const char *label; } items[] = {
        {0x38, 2, "Position"},
        {0x3E, 1, "Voltage"},
        {0x3F, 1, "Temperature"},
        {0x3C, 2, "Load"},
        {0x45, 2, "Current"}
    };

    char buf[64];
    for (uint8_t i = 0; i < sizeof(items)/sizeof(items[0]); i++) {
        uint8_t req[] = {0xFF, 0xFF, SERVO_ID, 0x04, 0x02, items[i].addr, items[i].size, 0x00};
        req[7] = calc_checksum(&req[2], 5);
        packet_ready = 0;
        send_packet(SERVO_ID, 0x02, &req[5], 2);

        uint32_t start = HAL_GetTick();
        while (!packet_ready && (HAL_GetTick() - start) < 20);

        if (packet_ready && packet_buf[0] == 0xFF && packet_buf[1] == 0xFF) {
            uint8_t err = packet_buf[4];
            const uint8_t *params = &packet_buf[5];
            if (err == 0) {
                if (items[i].addr == 0x3E) { // Voltage
                    float v = params[0] * 0.1f + 0.1f;
                    sprintf(buf, "%s: %.2f V   ", items[i].label, v);
                } else if (items[i].addr == 0x45) { // Current
                    uint16_t raw = params[0] | (params[1] << 8);
                    sprintf(buf, "%s: %.1f mA   ", items[i].label, raw * 10.0f);
                } else {
                    uint16_t val = (items[i].size == 1) ? params[0] : (params[0] | (params[1] << 8));
                    sprintf(buf, "%s: %u   ", items[i].label, val);
                }
            } else {
                sprintf(buf, "%s: Error   ", items[i].label);
            }
        } else {
            sprintf(buf, "%s: Timeout   ", items[i].label);
        }
        HAL_UART_Transmit(&huart3, (uint8_t*)buf, strlen(buf), HAL_MAX_DELAY);
    }
    HAL_UART_Transmit(&huart3, (uint8_t*)"\r\n", 2, HAL_MAX_DELAY);
}

/* ------------------- RX byte handler ------------------- */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
    static uint8_t idx = 0;
    static uint8_t len = 0;

    if (huart->Instance == USART2) {
        uint8_t b = uart2_rx_byte;

        if (idx == 0 && b == 0xFF) { packet_buf[idx++] = b; }
        else if (idx == 1 && b == 0xFF) { packet_buf[idx++] = b; }
        else if (idx == 2) { packet_buf[idx++] = b; }
        else if (idx == 3) { len = b; packet_buf[idx++] = b; }
        else {
            packet_buf[idx++] = b;
            if (idx >= len + 4) { // 4 header bytes + LEN
                packet_len = idx;
                packet_ready = 1;
                idx = 0;
            }
        }

        HAL_UART_Receive_IT(&huart2, &uart2_rx_byte, 1);
    }
}
/* USER CODE END 0 */

/**
 * @brief  The application entry point.
 * @retval int
 */
int main(void) {
    HAL_Init();
    SystemClock_Config();
    MX_GPIO_Init();
    MX_USART2_UART_Init();
    MX_USART3_UART_Init();

    /* Arm continuous byte-by-byte RX */
    HAL_UART_Receive_IT(&huart2, &uart2_rx_byte, 1);

    while (1) {
        servo_set_angle(30);
        feedback();
        HAL_Delay(50);
    }
}

/**
 * @brief System Clock Configuration
 * @retval None
 */
void SystemClock_Config(void) {
    RCC_OscInitTypeDef RCC_OscInitStruct = { 0 };
    RCC_ClkInitTypeDef RCC_ClkInitStruct = { 0 };
    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
    RCC_OscInitStruct.HSEState = RCC_HSE_ON;
    RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
    RCC_OscInitStruct.HSIState = RCC_HSI_ON;
    RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
    RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
    RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) { Error_Handler(); }

    RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
                                | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
    RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK) { Error_Handler(); }
}

/**
 * @brief USART2 Initialization Function
 * @param None
 * @retval None
 */
static void MX_USART2_UART_Init(void) {
    huart2.Instance = USART2;
    huart2.Init.BaudRate = 1000000;
    huart2.Init.WordLength = UART_WORDLENGTH_8B;
    huart2.Init.StopBits = UART_STOPBITS_1;
    huart2.Init.Parity = UART_PARITY_NONE;
    huart2.Init.Mode = UART_MODE_TX_RX;
    huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
    huart2.Init.OverSampling = UART_OVERSAMPLING_16;
    if (HAL_UART_Init(&huart2) != HAL_OK) { Error_Handler(); }
}

/**
 * @brief USART3 Initialization Function
 * @param None
 * @retval None
 */
static void MX_USART3_UART_Init(void) {
    huart3.Instance = USART3;
    huart3.Init.BaudRate = 115200;
    huart3.Init.WordLength = UART_WORDLENGTH_8B;
    huart3.Init.StopBits = UART_STOPBITS_1;
    huart3.Init.Parity = UART_PARITY_NONE;
    huart3.Init.Mode = UART_MODE_TX_RX;
    huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
    huart3.Init.OverSampling = UART_OVERSAMPLING_16;
    if (HAL_UART_Init(&huart3) != HAL_OK) { Error_Handler(); }
}

/**
 * @brief GPIO Initialization Function
 * @param None
 * @retval None
 */
static void MX_GPIO_Init(void) {
    GPIO_InitTypeDef GPIO_InitStruct = { 0 };

    __HAL_RCC_GPIOD_CLK_ENABLE();
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();

    HAL_GPIO_WritePin(GPIOA, RS485_RE_DE_Pin, GPIO_PIN_RESET); /* default to RX (RE=0, DE=0) */

    GPIO_InitStruct.Pin = RS485_RE_DE_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(RS485_RE_DE_GPIO_Port, &GPIO_InitStruct);
}

/**
 * @brief  This function is executed in case of error occurrence.
 * @retval None
 */
void Error_Handler(void) {
    __disable_irq();
    while (1) { }
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line) { (void)file; (void)line; }
#endif
