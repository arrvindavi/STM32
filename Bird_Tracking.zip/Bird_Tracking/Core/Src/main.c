/* main.c
 * Integrated RS-485 pan (RSBL45) + PWM tilt + telemetry parser
 * Behavior: AUTO (GPS+IMU+heading fusion) / MANUAL (GUI) with instant resume on AUTO re-entry.
 */

#include "main.h"
#include "stm32f1xx_hal.h"
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <stdio.h>
#include <ctype.h>

/* ---------- CONFIG ---------- */
#define UART_BUF_SIZE 256

/* RSBL / RS485 specifics */
#define RS485_RE_DE_Pin        GPIO_PIN_4
#define RS485_RE_DE_GPIO_Port  GPIOA
#define RSBL_SERVO_ID          1
#define RSBL_SERVO_MAX_POS     4095
#define RSBL_SERVO_MOVE_TIME   0x20

/* Tilt PWM */
#define TILT_SERVO_MAX_DEG     180

/* Fusion constants */
static const float FUSE_ALPHA = 0.98f;

/* ---------- Peripherals ---------- */
TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim2;
UART_HandleTypeDef huart1; // telemetry (USART1)
UART_HandleTypeDef huart2; // RS485 (USART2)
UART_HandleTypeDef huart3; // debug / feedback (USART3)

/* ---------- Buffers & state ---------- */
/* Telemetry input */
char gps_buff[UART_BUF_SIZE];
uint8_t uart_rx_data;
uint16_t uart_rx_index = 0;
volatile uint8_t nmea_sentence_ready = 0;

/* RSBL RX (USART2) */
uint8_t uart2_rx_byte = 0;

volatile uint8_t rsbl_packet_ready = 0;
uint8_t rsbl_packet_buf[64];
uint8_t rsbl_packet_len = 0;

/* Dynamic tuning (runtime adjustable) */
volatile float SERVO_SMOOTHING = 0.10f;   /* 0..1 : higher -> more smoothing */
volatile float SERVO_GAIN = 1.30f;        /* control gain */
volatile float SERVO_DEADBAND = 0.80f;    /* degrees: ignore tiny corrections */
volatile float HEADING_OFFSET = 0.0f;

/* Ground coordinates (dynamic) */
volatile float ground_lat_var = 17.441000f;
volatile float ground_lon_var = 78.390000f;
volatile float last_ground_alt = 0.0f;

/* Fusion state */
static float fused_heading = 0.0f;
static float last_yaw_deg = 0.0f;
static uint32_t last_fuse_ms = 0;
volatile uint8_t pending_auto_init = 0;


/* Additional servo telemetry */
volatile uint16_t servo_load = 0;     // 2 bytes (0..1000 => 0..100%)
volatile uint8_t  servo_voltage = 0;  // 1 byte (units 0.1V)
volatile uint8_t  servo_temp = 0;     // 1 byte (deg C)
volatile uint8_t  servo_status = 0;   // 1 byte bitfield
volatile uint16_t servo_current = 0;  // 2 bytes (counts -> 6.5mA per count)
volatile uint16_t servo_bias = 0;     // 2 bytes
static uint32_t fb_timestamp = 0;


volatile uint16_t servo_position = 2048;   // absolute RSBL feedback (0..4095)
volatile int16_t servo_speed = 0;
volatile uint16_t last_rsbl_pos = 2048;   // last commanded (and tracked) pos
volatile int8_t PAN_DIRECTION = 1;

/* Mode and manual base */
int current_mode = 0;      // 0 = AUTO, 1 = MANUAL
int prev_mode = 0;
volatile uint16_t manual_base_pos = 2048; // base position in counts when manual was entered
volatile float manual_base_deg = 180.0f;  // convenience

/* Flags */
volatile uint8_t mode_initialized = 0;

/* ---------- Prototypes ---------- */
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM1_Init(void);
static void MX_TIM2_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_USART3_UART_Init(void);
void process_nmea_sentence(char *nmea);
void process_tune_command(char *nmea);
static void rsbl_send_packet(uint8_t id, uint8_t instruction,
		const uint8_t *params, uint8_t param_len);
static void rsbl_set_goal_position(uint8_t id, uint16_t position,
		uint16_t time_ms);
static uint16_t angle_to_rsbl_position(int angle);
static uint8_t rsbl_calc_checksum(const uint8_t *data, uint8_t len);
static inline void RS485_TxEnable(void);
static inline void RS485_TxDisable(void);
float calculate_bearing(float lat1, float lon1, float lat2, float lon2);
float haversine_distance_m(float lat1, float lon1, float lat2, float lon2);
static uint8_t compute_xor_checksum(const char *body);
void update_fused_heading_from_samples(float yaw_rad, float mag_heading_deg);
/* Removed roll/pitch from prototype as requested */
void gps_magnetometer_imu(float lat, float lon, float alt, float compass, float yaw);
static void rsbl_feedback_update(void);

static void send_feedback_uart3(const char *payload_body, int mode_val,
        uint16_t rsbl_pos, float fused_deg, float bearing_deg, float dist_m);

/* ---------- RS485 helpers ---------- */
static inline void RS485_TxEnable(void) {
	HAL_GPIO_WritePin(RS485_RE_DE_GPIO_Port, RS485_RE_DE_Pin, GPIO_PIN_SET);
}
static inline void RS485_TxDisable(void) {
	HAL_GPIO_WritePin(RS485_RE_DE_GPIO_Port, RS485_RE_DE_Pin, GPIO_PIN_RESET);
}

static uint8_t rsbl_calc_checksum(const uint8_t *data, uint8_t len) {
	uint16_t sum = 0;
	for (uint8_t i = 0; i < len; ++i)
		sum += data[i];
	return (uint8_t) (~sum);
}
/* Helper: apply pan direction to a RSBL position (0..RSBL_SERVO_MAX_POS) */
static inline uint16_t apply_pan_direction(uint16_t pos) {
    if (PAN_DIRECTION == -1) {
        return (uint16_t)(RSBL_SERVO_MAX_POS - (pos & RSBL_SERVO_MAX_POS));
    }
    return pos & RSBL_SERVO_MAX_POS;
}

static void rsbl_send_packet(uint8_t id, uint8_t instruction,
		const uint8_t *params, uint8_t param_len) {
	uint8_t packet[32];
	uint8_t idx = 0;
	packet[idx++] = 0xFF;
	packet[idx++] = 0xFF;
	packet[idx++] = id;
	packet[idx++] = param_len + 2;
	packet[idx++] = instruction;
	if (param_len) {
		memcpy(&packet[idx], params, param_len);
		idx += param_len;
	}
	uint8_t chk = rsbl_calc_checksum(&packet[2], (uint8_t) (param_len + 3)); // id + len + instr + params
	packet[idx++] = chk;

	RS485_TxEnable();
	HAL_UART_Transmit(&huart2, packet, idx, HAL_MAX_DELAY);
	while (!__HAL_UART_GET_FLAG(&huart2, UART_FLAG_TC))
		;
	RS485_TxDisable();
}

static void rsbl_set_goal_position(uint8_t id, uint16_t position,
                                   uint16_t time_ms)
{
    if (position > RSBL_SERVO_MAX_POS)
        position = RSBL_SERVO_MAX_POS;

    uint16_t send_pos = apply_pan_direction(position);

    last_rsbl_pos = send_pos;

    uint8_t params[5];
    params[0] = 0x2A;
    params[1] = (uint8_t)(send_pos & 0xFF);
    params[2] = (uint8_t)((send_pos >> 8) & 0xFF);
    params[3] = (uint8_t)(time_ms & 0xFF);
    params[4] = 0x00;

    /* TX phase */
    RS485_TxEnable();
    rsbl_send_packet(id, 0x03, params, sizeof(params));

    /* Switch to RX immediately */
    while (!__HAL_UART_GET_FLAG(&huart2, UART_FLAG_TC));
    RS485_TxDisable();

    /* RX window for servo reply */
    HAL_Delay(3);
}

/* convert angle 0..360 -> position 0..4095 */
static uint16_t angle_to_rsbl_position(int angle) {
	if (angle < 0)
		angle = 0;
	if (angle > 360)
		angle = 360;
	float posf = ((float) angle / 360.0f) * (float) RSBL_SERVO_MAX_POS;
	if (posf < 0.0f)
		posf = 0.0f;
	if (posf > RSBL_SERVO_MAX_POS)
		posf = RSBL_SERVO_MAX_POS;
	return (uint16_t) (posf + 0.5f);
}

/* ---------- Telemetry / Parser ---------- */
static uint8_t compute_xor_checksum(const char *body) {
	uint8_t cs = 0;
	for (const char *p = body; *p; ++p)
		cs ^= (uint8_t) (*p);
	return cs;
}

void process_tune_command(char *nmea) {
	// $TUNE,PARAM,VALUE*CS  (or without *CS)
	char *star = strchr(nmea, '*');
	if (star)
		*star = '\0';
	char *tokens[4];
	int i = 0;
	char *tok = strtok(nmea + 6, ",");
	while (tok && i < 4) {
		tokens[i++] = tok;
		tok = strtok(NULL, ",");
	}
	if (i < 2)
		return;
	const char *param = tokens[0];
	float val = atof(tokens[1]);
	if (strcasecmp(param, "SMOOTH") == 0)
		SERVO_SMOOTHING = val;
	else if (strcasecmp(param, "GAIN") == 0)
		SERVO_GAIN = val;
	else if (strcasecmp(param, "DEADBAND") == 0)
		SERVO_DEADBAND = val;
	else if (strcasecmp(param, "OFFSET") == 0) {
		HEADING_OFFSET = val;
		printf("🔧 OFFSET=%.2f\n", HEADING_OFFSET);
	} else
		return;
	printf("🔧 TUNE %s=%.2f\n", param, val);
}

/* parse telemetry NMEA-like, update local variables and mode */
int parse_telemetry_sentence(const char *nmea, float *dlat, float *dlon,
		float *dalt, float *glat, float *glon, float *galt, float *heading,
		float *yaw, float *manual_pan, float *manual_tilt, int *mode_flag) {
	if (!nmea || nmea[0] != '$')
		return 0;
	const char *star = strchr(nmea, '*');
	if (!star)
		return 0;
	// checksum
	uint8_t calc = 0;
	const char *p = nmea + 1;
	while (p < star) {
		calc ^= (uint8_t) (*p);
		p++;
	}
	unsigned int provided = (unsigned int) strtoul(star + 1, NULL, 16);
	if (provided != calc)
		return 0;
	char copy[UART_BUF_SIZE];
	strncpy(copy, nmea + 1, UART_BUF_SIZE - 1);
	copy[UART_BUF_SIZE - 1] = '\0';
	char *sp = strchr(copy, '*');
	if (sp)
		*sp = '\0';
	char *tokens[16];
	int i = 0;
	char *t = strtok(copy, ",");
	while (t && i < 16) {
		tokens[i++] = t;
		t = strtok(NULL, ",");
	}
	if (i < 11)
		return 0;
	*dlat = atof(tokens[0]);
	*dlon = atof(tokens[1]);
	*dalt = atof(tokens[2]);
	*glat = atof(tokens[3]);
	*glon = atof(tokens[4]);
	*galt = atof(tokens[5]);
	*heading = atof(tokens[6]);
	*yaw = atof(tokens[7]);
	*manual_pan = atof(tokens[8]);
	*manual_tilt = atof(tokens[9]);
	*mode_flag = atoi(tokens[10]);
	return 1;
}

void process_nmea_sentence(char *nmea)
{
    if (!nmea) return;

    /* Keep feedback alive */
    rsbl_feedback_update();

    /* Trim newline */
    size_t len = strlen(nmea);
    while (len > 0 && (nmea[len-1] == '\n' || nmea[len-1] == '\r')) nmea[--len] = '\0';

    /* TUNE */
    if (strncmp(nmea, "$TUNE,", 6) == 0) {
        process_tune_command(nmea);
        return;
    }
    if (nmea[0] != '$') return;

    float dlat, dlon, dalt;
    float glat, glon, galt;
    float heading, yaw;
    float manual_pan_f, manual_tilt_f;
    int incoming_mode_flag;

    int ok = parse_telemetry_sentence(nmea,
                                      &dlat,&dlon,&dalt,
                                      &glat,&glon,&galt,
                                      &heading,&yaw,
                                      &manual_pan_f,&manual_tilt_f,
                                      &incoming_mode_flag);
    if (!ok) return;

    /* update globals */
    last_ground_alt = galt;
    ground_lat_var  = glat;
    ground_lon_var  = glon;

    /* apply offset & normalize */
    heading += HEADING_OFFSET;
    while (heading >= 360.f) heading -= 360.f;
    while (heading < 0.f)    heading += 360.f;

    update_fused_heading_from_samples(yaw, heading);

    int new_mode = (incoming_mode_flag == 1) ? 1 : 0;
    static int ignore_frames = 0;

    if (!mode_initialized) {
        mode_initialized = 1;
        prev_mode = new_mode;
    }

    /* MODE SWITCH DETECTION */
    if (new_mode != prev_mode) {
        /* make sure we have freshest servo info before any sync */
        rsbl_feedback_update();
        HAL_Delay(2);
        rsbl_feedback_update();

        if (new_mode == 1) { /* AUTO -> MANUAL */
            /* Sync manual base to actual hardware position immediately.
             * Also set last_rsbl_pos and servo_position so manual starts from
             * real servo angle, not stale manual memory.
             */
            manual_base_pos = servo_position;
            manual_base_deg = ((float)manual_base_pos * 360.0f) / (float)RSBL_SERVO_MAX_POS;
            manual_pan_f = 0.0f;     /* ensure incoming packet doesn't cause jump */
            last_rsbl_pos = manual_base_pos;
            servo_position = manual_base_pos;

            ignore_frames = 2;
            pending_auto_init = 0;

            printf(">> AUTO->MANUAL synced base=%u deg=%.2f\n", manual_base_pos, manual_base_deg);
        } else { /* MANUAL -> AUTO */
            pending_auto_init = 1;
            /* ensure the integrator will sync to the real hardware pos */
            printf(">> MANUAL->AUTO pending init (servo_pos=%u)\n", servo_position);
        }
    }

    /* MANUAL MODE */
    if (new_mode == 1) {
        /* keep FB fresh */
        rsbl_feedback_update();

        if (ignore_frames > 0) {
            ignore_frames--;
            prev_mode = new_mode;
            current_mode = new_mode;
            return;
        }

        /* target is relative to manual_base */
        float target_deg = manual_base_deg + manual_pan_f;
        while (target_deg >= 360.f) target_deg -= 360.f;
        while (target_deg < 0.f)    target_deg += 360.f;

        uint16_t pos = angle_to_rsbl_position((int)(target_deg + 0.5f));

        if (fabsf(manual_pan_f) > 0.0001f) {
            rsbl_set_goal_position(RSBL_SERVO_ID, pos, RSBL_SERVO_MOVE_TIME);
            last_rsbl_pos = pos;
            /* optimistically reflect commanded position so higher logic (and UI) see it */
            servo_position = pos;
        } else {
            /* hold at base position explicitly */
            last_rsbl_pos = manual_base_pos;
            servo_position = manual_base_pos;
            /* request fresh feedback but do not stomp fb_state directly */
            rsbl_feedback_update();
        }

        prev_mode = new_mode;
        current_mode = new_mode;
        return;
    }

    /* AUTO MODE */
    /* perform tracking calculation and command moves inside gps_magnetometer_imu() */
    gps_magnetometer_imu(dlat, dlon, dalt, heading, yaw);

    /* send telemetry out */
    char body[UART_BUF_SIZE];
    snprintf(body, sizeof(body),
             "%.6f,%.6f,%.2f,%.6f,%.6f,%.2f,%.2f,%.3f,%.2f,%.2f,%d",
             dlat, dlon, dalt,
             ground_lat_var, ground_lon_var, last_ground_alt,
             heading, yaw, manual_pan_f, manual_tilt_f,
             incoming_mode_flag);

    float bearing = calculate_bearing(ground_lat_var, ground_lon_var, dlat, dlon);
    float distance_m = haversine_distance_m(ground_lat_var, ground_lon_var, dlat, dlon);
    send_feedback_uart3(body, new_mode, last_rsbl_pos, fused_heading, bearing, distance_m);

    prev_mode = new_mode;
    current_mode = new_mode;
}

/* ---------- Improved gps_magnetometer_imu (no roll/pitch) ----------
   Improvements:
    - Low-pass bearing with SERVO_SMOOTHING to reduce GPS jitter
    - Spike protection: if bearing jumps large while fused heading is stable, clamp jump
    - Deadband: ignore tiny corrections under SERVO_DEADBAND degrees
    - Smoothing on delta applied to accumulator using SERVO_SMOOTHING
    - Keeps existing safety windows and pending_auto_init behavior
*/
void gps_magnetometer_imu(float lat, float lon, float alt, float compass, float yaw)
{
    const float RAD2DEG = 57.295779513f;

    float raw_bearing = calculate_bearing(ground_lat_var, ground_lon_var, lat, lon);
    if (raw_bearing < 0.f) raw_bearing += 360.f;
    if (raw_bearing >= 360.f) raw_bearing -= 360.f;

    float horiz = haversine_distance_m(ground_lat_var, ground_lon_var, lat, lon);
    if (horiz < 1.f) horiz = 1.f;

    float elev = atanf((alt - last_ground_alt) / horiz) * RAD2DEG;

    /* Tracking state */
    static float virt = 0.f;
    static float last_virt = 0.f;
    static int32_t accumulated_pos = 2048;
    static int32_t turn_accum = 0;

    static uint32_t auto_init_time_ms = 0;
    const uint32_t AUTO_INIT_HOLD_MS = 120;

    /* Smoothing / spike protection locals */
    static float bearing_lp = -1.0f;         /* low-pass (smoothed) bearing */
    static float last_bearing_lp = 0.0f;
    static float last_fused_heading = 0.0f;

    /* Initialize bearing LP on first run */
    if (bearing_lp < -0.5f) {
        bearing_lp = raw_bearing;
        last_bearing_lp = bearing_lp;
        last_fused_heading = fused_heading;
    }

    /* Spike protection: limit large jumps if fused heading is steady */
    float fused_change = fabsf(fmodf(fused_heading - last_fused_heading + 540.f, 360.f) - 180.f);
    last_fused_heading = fused_heading;

    /* Low-pass the raw bearing */
    float alpha = SERVO_SMOOTHING;
    if (alpha < 0.0f) alpha = 0.0f;
    if (alpha > 0.95f) alpha = 0.95f; /* avoid total lock */
    bearing_lp = (1.0f - alpha) * bearing_lp + alpha * raw_bearing;

    /* Correct wrap-around issues while comparing */
    float d_bearing = fmodf(bearing_lp - last_bearing_lp + 540.f, 360.f) - 180.f;

    /* If jump is too large and fused heading stable, clamp the jump */
    const float MAX_ALLOWED_JUMP = 45.0f; /* degrees */
    if (fabsf(d_bearing) > MAX_ALLOWED_JUMP && fused_change < 10.0f) {
        if (d_bearing > 0)
            d_bearing = MAX_ALLOWED_JUMP;
        else
            d_bearing = -MAX_ALLOWED_JUMP;
        bearing_lp = last_bearing_lp + d_bearing;
        if (bearing_lp < 0.f) bearing_lp += 360.f;
        if (bearing_lp >= 360.f) bearing_lp -= 360.f;
    }
    last_bearing_lp = bearing_lp;

    /* MANUAL -> AUTO init: sync integrator to real hardware */
    if (pending_auto_init) {
        virt = ((float)servo_position * 360.f) / (float)RSBL_SERVO_MAX_POS;
        last_virt = virt;
        accumulated_pos = servo_position;
        turn_accum = 0;

        pending_auto_init = 0;
        auto_init_time_ms = HAL_GetTick();

        /* hold at the exact hardware position */
        rsbl_set_goal_position(RSBL_SERVO_ID, (uint16_t)accumulated_pos, RSBL_SERVO_MOVE_TIME);
        last_rsbl_pos = (uint16_t)accumulated_pos;
        /* reflect commanded hold immediately */
        servo_position = (uint16_t)accumulated_pos;

        printf("AUTO INIT sync: pos=%u virt=%.2f\n", (unsigned)servo_position, virt);
        return;
    }

    /* short hold window (let servo settle) */
    if (auto_init_time_ms && (HAL_GetTick() - auto_init_time_ms) < AUTO_INIT_HOLD_MS) {
        static uint32_t last_hold_tx = 0;
        if (HAL_GetTick() - last_hold_tx > 80) {
            rsbl_set_goal_position(RSBL_SERVO_ID, (uint16_t)accumulated_pos, RSBL_SERVO_MOVE_TIME);
            last_rsbl_pos = (uint16_t)accumulated_pos;
            servo_position = (uint16_t)accumulated_pos;
            last_hold_tx = HAL_GetTick();
        }
        return;
    }

    /* -------- tracking math (improved smoothing & deadband) -------- */
    float target = bearing_lp;

    /* closest-angle difference */
    float current_virt_mod = fmodf(virt, 360.f);
    float diff = fmodf(target - current_virt_mod + 540.f, 360.f) - 180.f;

    /* apply deadband: ignore tiny oscillations */
    if (fabsf(diff) < SERVO_DEADBAND) {
        diff = 0.0f;
    }

    /* integrate with gain */
    virt += diff * SERVO_GAIN;

    /* wrap detection */
    if (last_virt < 90.f && virt > 270.f) turn_accum--;
    if (last_virt > 270.f && virt < 90.f) turn_accum++;
    last_virt = virt;

    float total_angle = virt + 360.f * turn_accum;

    int32_t cur = (int32_t)fmodf((total_angle / 360.f) * (float)RSBL_SERVO_MAX_POS,
                                 (float)RSBL_SERVO_MAX_POS);
    if (cur < 0) cur += RSBL_SERVO_MAX_POS;

    int16_t delta = (int16_t)(cur - (int32_t)(accumulated_pos & RSBL_SERVO_MAX_POS));
    if (delta > 2048)  delta -= 4096;
    if (delta < -2048) delta += 4096;
    if (delta > 1024)  delta = 1024;
    if (delta < -1024) delta = -1024;

    /* Smooth delta before applying to accumulator to reduce jitter */
    float deltaf = (float)delta * (1.0f - SERVO_SMOOTHING);
    /* Ensure minimum step if there is movement to avoid stalling */
    if (delta != 0 && fabsf(deltaf) < 1.0f) deltaf = (delta > 0) ? 1.0f : -1.0f;
    int16_t delta_smoothed = (int16_t)deltaf;

    accumulated_pos += delta_smoothed;
    if (accumulated_pos >= 4096) accumulated_pos -= 4096;
    if (accumulated_pos < 0) accumulated_pos += 4096;

    /* send move every 100ms and request feedback safely */
    static uint32_t last_tx = 0;
    if (HAL_GetTick() - last_tx > 100) {
        uint16_t cmd = (uint16_t)accumulated_pos;
        rsbl_set_goal_position(RSBL_SERVO_ID, cmd, RSBL_SERVO_MOVE_TIME);

        last_rsbl_pos = cmd;
        /* optimistic update: show intended position until real FB arrives */
        servo_position = cmd;

        last_tx = HAL_GetTick();

        /* request feedback through normal FSM: do NOT forcibly stomp fb_state */
        rsbl_feedback_update();
    }

    printf("[AUTO] bearing=%.2f lp=%.2f virt=%.2f abs=%ld tilt=%.2f\n",
           raw_bearing, bearing_lp, virt, (long)accumulated_pos, elev);
}

/* ---------- Fusion ---------- */
void update_fused_heading_from_samples(float yaw_rad, float mag_heading_deg) {
	uint32_t now = HAL_GetTick();
	float dt = 0.02f;
	if (last_fuse_ms != 0) {
		uint32_t delta_ms = (now - last_fuse_ms);
		if (delta_ms == 0)
			dt = 0.02f;
		else
			dt = (float) delta_ms * 0.001f;
		if (dt <= 0.0f || dt > 1.0f)
			dt = 0.02f;
	}
	last_fuse_ms = now;

	float yaw_deg = yaw_rad * 57.295779513f;
	float dy = yaw_deg - last_yaw_deg;
	while (dy > 180.0f)
		dy -= 360.0f;
	while (dy < -180.0f)
		dy += 360.0f;
	float gyro_rate_deg_s = dy / dt;
	last_yaw_deg = yaw_deg;

	float pred = fused_heading + gyro_rate_deg_s * dt;
	while (pred >= 360.0f)
		pred -= 360.0f;
	while (pred < 0.0f)
		pred += 360.0f;

	float mag = mag_heading_deg;
	while (mag >= 360.0f)
		mag -= 360.0f;
	while (mag < 0.0f)
		mag += 360.0f;

	float diff = mag - pred;
	while (diff > 180.0f)
		diff -= 360.0f;
	while (diff < -180.0f)
		diff += 360.0f;

	float alpha = FUSE_ALPHA;
	if (fabsf(diff) > 45.0f)
		fused_heading = pred + (1.0f - alpha) * diff * 0.1f;
	else
		fused_heading = pred + (1.0f - alpha) * diff;

	while (fused_heading >= 360.0f)
		fused_heading -= 360.0f;
	while (fused_heading < 0.0f)
		fused_heading += 360.0f;
}

/* ---------- Feedback sender ---------- */
static void send_feedback_uart3(const char *payload_body, int mode_val,
        uint16_t rsbl_pos, float fused_deg, float bearing_deg, float dist_m)
{
    /* Build original payload first (same fields as before) then append new servo fields */
    char buf[384];
    int n = snprintf(buf, sizeof(buf),
            "%s,MODE:%d,POS:%u,SPD:%+d,LOAD:%u,VOLT:%.1f,TEMP:%u,CURR:%.3f,STATUS:%u,FUSED:%.2f,BEARING:%.2f,DIST:%.2f",
            payload_body,
            mode_val,
            (unsigned) rsbl_pos,
            (int) servo_speed,
            (unsigned) servo_load,
            ((float)servo_voltage) * 0.1f, /* convert 0.1V -> V */
            (unsigned) servo_temp,
            ((float)servo_current) * 0.0065f, /* example conversion: 6.5mA/count -> A */
            (unsigned) servo_status,
            fused_deg,
            bearing_deg,
            dist_m
            );

    if (n <= 0) return;
    uint8_t cs = compute_xor_checksum(buf);
    char tx[420];
    int tn = snprintf(tx, sizeof(tx), "$%s*%02X\n", buf, cs);
    if (tn <= 0) return;
    HAL_UART_Transmit(&huart3, (uint8_t*) tx, (uint16_t) tn, HAL_MAX_DELAY);
}


/* ---------- RSBL feedback RX parser (USART2) ---------- */
/*
 * Simple parser for Waveshare RSBL reply frames:
 * Frame: 0xFF 0xFF ID LEN ... DATA ... CHK
 * We'll accumulate bytes in an ISR and set rsbl_packet_ready when full frame assembled.
 * HAL UART RX IT used below.
 */

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
	static uint8_t idx = 0;
	static uint8_t expected_len = 0;

	if (huart->Instance == USART1) {
		// telemetry UART handler
		if (uart_rx_index < UART_BUF_SIZE - 1) {
			gps_buff[uart_rx_index++] = uart_rx_data;
			if (uart_rx_data == '\n') {
				gps_buff[uart_rx_index] = '\0';
				nmea_sentence_ready = 1;
			}
		} else {
			uart_rx_index = 0;
		}
		HAL_UART_Receive_IT(&huart1, &uart_rx_data, 1);
	} else if (huart->Instance == USART2) {
		uint8_t b = uart2_rx_byte;
		if (idx == 0) {
			if (b == 0xFF) {
				rsbl_packet_buf[idx++] = b;
			} else
				idx = 0;
		} else if (idx == 1) {
			if (b == 0xFF) {
				rsbl_packet_buf[idx++] = b;
			} else
				idx = 0;
		} else if (idx == 2) {
			rsbl_packet_buf[idx++] = b; // ID
		} else if (idx == 3) {
			rsbl_packet_buf[idx++] = b; // LEN
			expected_len = b;
		} else {
			rsbl_packet_buf[idx++] = b;
			if (idx >= (uint8_t) (expected_len + 4)) {
				rsbl_packet_len = idx;
				rsbl_packet_ready = 1;
				// reset idx for next frame
				idx = 0;
			}
		}
		HAL_UART_Receive_IT(&huart2, &uart2_rx_byte, 1);
	}
}

/* RSBL feedback FSM that requests pos & speed and decodes incoming frames */

/* RSBL feedback FSM that cycles through full telemetry set */
typedef enum {
    FB_IDLE,
    FB_REQ_POS, FB_WAIT_POS,
    FB_REQ_SPD, FB_WAIT_SPD,
    FB_REQ_LOAD, FB_WAIT_LOAD,
    FB_REQ_VOLT, FB_WAIT_VOLT,
    FB_REQ_TEMP, FB_WAIT_TEMP,
    FB_REQ_STATUS, FB_WAIT_STATUS,
    FB_REQ_CURR, FB_WAIT_CURR,
    FB_REQ_BIAS, FB_WAIT_BIAS
} fb_full_state_t;
static fb_full_state_t fb_full_state = FB_IDLE;

static void rsbl_feedback_update(void) {
    uint32_t now = HAL_GetTick();

    switch (fb_full_state) {
        case FB_IDLE:
            fb_full_state = FB_REQ_POS;
            break;

        case FB_REQ_POS: {
            uint8_t params[2] = { 0x38, 0x02 }; // present position (2)
            rsbl_send_packet(RSBL_SERVO_ID, 0x02, params, 2);
            rsbl_packet_ready = 0;
            fb_timestamp = now;
            fb_full_state = FB_WAIT_POS;
            break;
        }
        case FB_WAIT_POS:
            if (rsbl_packet_ready) {
                if (rsbl_packet_len >= 7) {
                    uint16_t val = (uint16_t)rsbl_packet_buf[5] | ((uint16_t)rsbl_packet_buf[6] << 8);
                    servo_position = val & 0x0FFF;
                }
                rsbl_packet_ready = 0;
                fb_full_state = FB_REQ_SPD;
            } else if (now - fb_timestamp > 25) {
                fb_full_state = FB_REQ_SPD;
            }
            break;

        case FB_REQ_SPD: {
            uint8_t params[2] = { 0x3A, 0x02 }; // present speed (2)
            rsbl_send_packet(RSBL_SERVO_ID, 0x02, params, 2);
            rsbl_packet_ready = 0;
            fb_timestamp = now;
            fb_full_state = FB_WAIT_SPD;
            break;
        }
        case FB_WAIT_SPD:
            if (rsbl_packet_ready) {
                if (rsbl_packet_len >= 7) {
                    uint16_t val = (uint16_t)rsbl_packet_buf[5] | ((uint16_t)rsbl_packet_buf[6] << 8);
                    if (val & 0x8000) servo_speed = -((int16_t)(val & 0x3FFF));
                    else servo_speed = (int16_t)(val & 0x3FFF);
                }
                rsbl_packet_ready = 0;
                fb_full_state = FB_REQ_LOAD;
            } else if (now - fb_timestamp > 25) {
                fb_full_state = FB_REQ_LOAD;
            }
            break;

        case FB_REQ_LOAD: {
            uint8_t params[2] = { 0x3C, 0x02 }; // present load (2)
            rsbl_send_packet(RSBL_SERVO_ID, 0x02, params, 2);
            rsbl_packet_ready = 0;
            fb_timestamp = now;
            fb_full_state = FB_WAIT_LOAD;
            break;
        }
        case FB_WAIT_LOAD:
            if (rsbl_packet_ready) {
                if (rsbl_packet_len >= 7) {
                    uint16_t val = (uint16_t)rsbl_packet_buf[5] | ((uint16_t)rsbl_packet_buf[6] << 8);
                    servo_load = val; /* unit per protocol (0..1000 => 0..100%) */
                }
                rsbl_packet_ready = 0;
                fb_full_state = FB_REQ_VOLT;
            } else if (now - fb_timestamp > 25) {
                fb_full_state = FB_REQ_VOLT;
            }
            break;

        case FB_REQ_VOLT: {
            uint8_t params[2] = { 0x3E, 0x01 }; // voltage (1)
            rsbl_send_packet(RSBL_SERVO_ID, 0x02, params, 2);
            rsbl_packet_ready = 0;
            fb_timestamp = now;
            fb_full_state = FB_WAIT_VOLT;
            break;
        }
        case FB_WAIT_VOLT:
            if (rsbl_packet_ready) {
                if (rsbl_packet_len >= 6) {
                    uint8_t val = rsbl_packet_buf[5];
                    servo_voltage = val; /* 0.1V units */
                }
                rsbl_packet_ready = 0;
                fb_full_state = FB_REQ_TEMP;
            } else if (now - fb_timestamp > 25) {
                fb_full_state = FB_REQ_TEMP;
            }
            break;

        case FB_REQ_TEMP: {
            uint8_t params[2] = { 0x3F, 0x01 }; // temp (1)
            rsbl_send_packet(RSBL_SERVO_ID, 0x02, params, 2);
            rsbl_packet_ready = 0;
            fb_timestamp = now;
            fb_full_state = FB_WAIT_TEMP;
            break;
        }
        case FB_WAIT_TEMP:
            if (rsbl_packet_ready) {
                if (rsbl_packet_len >= 6) {
                    uint8_t val = rsbl_packet_buf[5];
                    servo_temp = val; /* deg C */
                }
                rsbl_packet_ready = 0;
                fb_full_state = FB_REQ_STATUS;
            } else if (now - fb_timestamp > 25) {
                fb_full_state = FB_REQ_STATUS;
            }
            break;

        case FB_REQ_STATUS: {
            uint8_t params[2] = { 0x41, 0x01 }; // status (1)
            rsbl_send_packet(RSBL_SERVO_ID, 0x02, params, 2);
            rsbl_packet_ready = 0;
            fb_timestamp = now;
            fb_full_state = FB_WAIT_STATUS;
            break;
        }
        case FB_WAIT_STATUS:
            if (rsbl_packet_ready) {
                if (rsbl_packet_len >= 6) {
                    uint8_t val = rsbl_packet_buf[5];
                    servo_status = val;
                }
                rsbl_packet_ready = 0;
                fb_full_state = FB_REQ_CURR;
            } else if (now - fb_timestamp > 25) {
                fb_full_state = FB_REQ_CURR;
            }
            break;

        case FB_REQ_CURR: {
            uint8_t params[2] = { 0x45, 0x02 }; // current (2)
            rsbl_send_packet(RSBL_SERVO_ID, 0x02, params, 2);
            rsbl_packet_ready = 0;
            fb_timestamp = now;
            fb_full_state = FB_WAIT_CURR;
            break;
        }
        case FB_WAIT_CURR:
            if (rsbl_packet_ready) {
                if (rsbl_packet_len >= 7) {
                    uint16_t val = (uint16_t)rsbl_packet_buf[5] | ((uint16_t)rsbl_packet_buf[6] << 8);
                    servo_current = val; /* per protocol units (e.g. 6.5mA/count) */
                }
                rsbl_packet_ready = 0;
                fb_full_state = FB_REQ_BIAS;
            } else if (now - fb_timestamp > 25) {
                fb_full_state = FB_REQ_BIAS;
            }
            break;

        case FB_REQ_BIAS: {
            uint8_t params[2] = { 0x49, 0x02 }; // bias (2)
            rsbl_send_packet(RSBL_SERVO_ID, 0x02, params, 2);
            rsbl_packet_ready = 0;
            fb_timestamp = now;
            fb_full_state = FB_WAIT_BIAS;
            break;
        }
        case FB_WAIT_BIAS:
            if (rsbl_packet_ready) {
                if (rsbl_packet_len >= 7) {
                    uint16_t val = (uint16_t)rsbl_packet_buf[5] | ((uint16_t)rsbl_packet_buf[6] << 8);
                    servo_bias = val;
                }
                rsbl_packet_ready = 0;
                fb_full_state = FB_IDLE; /* cycle again */
            } else if (now - fb_timestamp > 25) {
                fb_full_state = FB_IDLE;
            }
            break;

        default:
            fb_full_state = FB_IDLE;
            break;
    }
}

/* ---------- Utility math ---------- */
float calculate_bearing(float lat1, float lon1, float lat2, float lon2) {
	const float DEG2RAD = 0.01745329252f;
	const float RAD2DEG = 57.295779513f;
	float phi1 = lat1 * DEG2RAD;
	float phi2 = lat2 * DEG2RAD;
	float d_lambda = (lon2 - lon1) * DEG2RAD;
	float y = sinf(d_lambda) * cosf(phi2);
	float x = cosf(phi1) * sinf(phi2)
			- sinf(phi1) * cosf(phi2) * cosf(d_lambda);
	float bearing = atan2f(y, x) * RAD2DEG;
	if (bearing < 0.0f)
		bearing += 360.0f;
	return bearing;
}

float haversine_distance_m(float lat1, float lon1, float lat2, float lon2) {
	const double R = 6371000.0;
	double phi1 = lat1 * M_PI / 180.0;
	double phi2 = lat2 * M_PI / 180.0;
	double dphi = (lat2 - lat1) * M_PI / 180.0;
	double dlambda = (lon2 - lon1) * M_PI / 180.0;
	double a = sin(dphi / 2.0) * sin(dphi / 2.0)
			+ cos(phi1) * cos(phi2) * sin(dlambda / 2.0) * sin(dlambda / 2.0);
	double c = 2.0 * atan2(sqrt(a), sqrt(1.0 - a));
	return (float) (R * c);
}

/* ---------- Main ---------- */
int main(void) {
	HAL_Init();
	SystemClock_Config();
	MX_GPIO_Init();
	MX_TIM1_Init();
	MX_TIM2_Init();
	MX_USART1_UART_Init();
	MX_USART2_UART_Init();
	MX_USART3_UART_Init();

	// Start interrupts
	HAL_UART_Receive_IT(&huart1, &uart_rx_data, 1); // telemetry
	HAL_UART_Receive_IT(&huart2, &uart2_rx_byte, 1); // RSBL feedback

	// Start PWM for tilt (not used for control here)
	HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);

	// Ensure RS485 in RX mode
	HAL_GPIO_WritePin(RS485_RE_DE_GPIO_Port, RS485_RE_DE_Pin, GPIO_PIN_RESET);

	// Initialize servo to center
	{
		int center_pan = 180; // center in 360 scale
		uint16_t center_pos = angle_to_rsbl_position(center_pan);
		rsbl_set_goal_position(RSBL_SERVO_ID, center_pos, RSBL_SERVO_MOVE_TIME);
	}
	// tilt center
	{
		float us = 500.0f
				+ ((float) 90.0f / (float) TILT_SERVO_MAX_DEG) * 2000.0f;
		__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, (uint32_t )us);
	}

	printf("=== START: RSBL + Telemetry Handler (instant auto resume) ===\r\n");

	uint32_t last_feedback_tick = HAL_GetTick();
	while (1) {
		if (nmea_sentence_ready) {
			nmea_sentence_ready = 0;
			process_nmea_sentence(gps_buff);
			uart_rx_index = 0;
			memset(gps_buff, 0, UART_BUF_SIZE);
		}

		// Poll RSBL feedback FSM frequently
		rsbl_feedback_update();

		// Print feedback at 20Hz
		uint32_t now = HAL_GetTick();
		if (now - last_feedback_tick >= 50) {
			char dbg[80];
			int n = snprintf(dbg, sizeof(dbg),
					"FB POS:%4u SPD:%+5d MODE:%d CMDPOS:%u\r\n",
					(unsigned) servo_position, (int) servo_speed, current_mode,
					(unsigned) last_rsbl_pos);
			if (n > 0)
				HAL_UART_Transmit(&huart3, (uint8_t*) dbg,
						(uint16_t) strlen(dbg), HAL_MAX_DELAY);
			last_feedback_tick = now;
		}
	}
}


/* --------------------------------------------------------------------------
 Below: SystemClock_Config, MX_* and Error_Handler. Use your existing
 CubeMX-generated implementations or paste the ones from your project.
 For clarity they are left as stubs here and should be replaced.
 -------------------------------------------------------------------------- */

void SystemClock_Config(void) {
	/* Copy your project's clock setup here */
	RCC_OscInitTypeDef RCC_OscInitStruct = { 0 };
	RCC_ClkInitTypeDef RCC_ClkInitStruct = { 0 };

	RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
	RCC_OscInitStruct.HSEState = RCC_HSE_ON;
	RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
	RCC_OscInitStruct.HSIState = RCC_HSI_ON;
	RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
	RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
	RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
	if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) {
		Error_Handler();
	}
	RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
			| RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
	RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
	RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
	RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
	RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
	if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK) {
		Error_Handler();
	}
}

/* Minimal peripheral init placeholders — replace with CubeMX versions */
static void MX_TIM1_Init(void) {
	TIM_MasterConfigTypeDef sMasterConfig = { 0 };
	TIM_OC_InitTypeDef sConfigOC = { 0 };
	TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig = { 0 };

	htim1.Instance = TIM1;
	htim1.Init.Prescaler = 72 - 1;
	htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
	htim1.Init.Period = 10000 - 1;
	htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
	htim1.Init.RepetitionCounter = 0;
	htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
	if (HAL_TIM_PWM_Init(&htim1) != HAL_OK) {
		Error_Handler();
	}
	sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
	sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
	if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig)
			!= HAL_OK) {
		Error_Handler();
	}
	sConfigOC.OCMode = TIM_OCMODE_PWM1;
	sConfigOC.Pulse = 0;
	sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
	sConfigOC.OCNPolarity = TIM_OCNPOLARITY_HIGH;
	sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
	sConfigOC.OCIdleState = TIM_OCIDLESTATE_RESET;
	sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
	if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_1)
			!= HAL_OK) {
		Error_Handler();
	}
	sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
	sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
	sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
	sBreakDeadTimeConfig.DeadTime = 0;
	sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
	sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
	sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
	if (HAL_TIMEx_ConfigBreakDeadTime(&htim1, &sBreakDeadTimeConfig)
			!= HAL_OK) {
		Error_Handler();
	}
	HAL_TIM_MspPostInit(&htim1);
}

static void MX_TIM2_Init(void) {
	TIM_MasterConfigTypeDef sMasterConfig = { 0 };
	TIM_OC_InitTypeDef sConfigOC = { 0 };

	htim2.Instance = TIM2;
	htim2.Init.Prescaler = 72 - 1;
	htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
	htim2.Init.Period = 20000 - 1;
	htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
	htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
	if (HAL_TIM_PWM_Init(&htim2) != HAL_OK) {
		Error_Handler();
	}
	sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
	sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
	if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig)
			!= HAL_OK) {
		Error_Handler();
	}
	sConfigOC.OCMode = TIM_OCMODE_PWM1;
	sConfigOC.Pulse = 0;
	sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
	sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
	if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_1)
			!= HAL_OK) {
		Error_Handler();
	}
	HAL_TIM_MspPostInit(&htim2);
}

static void MX_USART1_UART_Init(void) {
	huart1.Instance = USART1;
	huart1.Init.BaudRate = 115200;
	huart1.Init.WordLength = UART_WORDLENGTH_8B;
	huart1.Init.StopBits = UART_STOPBITS_1;
	huart1.Init.Parity = UART_PARITY_NONE;
	huart1.Init.Mode = UART_MODE_TX_RX;
	huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	huart1.Init.OverSampling = UART_OVERSAMPLING_16;
	if (HAL_UART_Init(&huart1) != HAL_OK) {
		Error_Handler();
	}
}

static void MX_USART2_UART_Init(void) {
	huart2.Instance = USART2;
	huart2.Init.BaudRate = 1000000;
	huart2.Init.WordLength = UART_WORDLENGTH_8B;
	huart2.Init.StopBits = UART_STOPBITS_1;
	huart2.Init.Parity = UART_PARITY_NONE;
	huart2.Init.Mode = UART_MODE_TX_RX;
	huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	huart2.Init.OverSampling = UART_OVERSAMPLING_16;
	if (HAL_UART_Init(&huart2) != HAL_OK) {
		Error_Handler();
	}
}

static void MX_USART3_UART_Init(void) {
	huart3.Instance = USART3;
	huart3.Init.BaudRate = 115200;
	huart3.Init.WordLength = UART_WORDLENGTH_8B;
	huart3.Init.StopBits = UART_STOPBITS_1;
	huart3.Init.Parity = UART_PARITY_NONE;
	huart3.Init.Mode = UART_MODE_TX_RX;
	huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	huart3.Init.OverSampling = UART_OVERSAMPLING_16;
	if (HAL_UART_Init(&huart3) != HAL_OK) {
		Error_Handler();
	}
}

static void MX_GPIO_Init(void) {
	GPIO_InitTypeDef GPIO_InitStruct = { 0 };

	__HAL_RCC_GPIOD_CLK_ENABLE();
	__HAL_RCC_GPIOA_CLK_ENABLE();
	__HAL_RCC_GPIOB_CLK_ENABLE();

	HAL_GPIO_WritePin(RS485_RE_DE_GPIO_Port, RS485_RE_DE_Pin, GPIO_PIN_RESET);

	GPIO_InitStruct.Pin = RS485_RE_DE_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(RS485_RE_DE_GPIO_Port, &GPIO_InitStruct);
}

/* redirect printf to huart3 for debug output */
int _write(int file, char *ptr, int len) {
	HAL_UART_Transmit(&huart3, (uint8_t*) ptr, len, HAL_MAX_DELAY);
	return len;
}

/* error handler */
void Error_Handler(void) {
	__disable_irq();
	while (1) {
	}
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line) {
    /* Optional: printf("Wrong parameters value: file %s on line %d\r\n", file, line); */
}
#endif

/* End of file */
